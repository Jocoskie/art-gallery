<!DOCTYPE html>
<html>
<head>
	<title> ART GALLERY </title>
	<link rel="stylesheet" href="style.css" type="text/css">

   </head>
<body>

		<font align="center">
			<h2>ART GALLERY</h2>
      </font>
		<nav>
		<ul>

			<li><a href = "home.php"> Home</a></li>
			<li><a href = "#"> Gallery</a></li>
			<li><a href = "contact.php"> Contact us</a></li>
      <div class="formbtn">
      <li><a href = "signupform.php"> Sign In </a></li>
      <div class="formbtn2">
      <li><a href = "loginform.php"> Log In</a></li>

		</ul>
    </nav>

   

<div class="container">
	<h3>Leave Comment</h3>
  <form action="/action_page.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="lname"> Adress</label>
    <input type="text" id="Adress" name="Adress" placeholder="Your adress..">

    <label for="subject">Comment</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" value="Submit">
  </form>
</div>
</div>

</body>
</html>




    <footer>
      All Right Reserved Art Galley
     </footer>

 </div>
</div>
</ul>
</nav>
</body>
</html>
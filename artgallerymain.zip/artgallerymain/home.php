<?php 
  include("connect2.php");

  if(@$_SESSION['activeUser'] != "")
  {
    echo "<script>alert('User has already logged in');</script>";
    echo "<script>window.open('userhome.php', '_self');</script>";
  }

  if(@$_SESSION['activeUser1'] != ""){
    echo "<script>alert('User has already logged in');</script>";
    echo "<script>window.open('admin/adminhome.php', '_self');</script>";
  }
?>


<!DOCTYPE html>
<html>
<head>
	<title> ART GALLERY </title>
	<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
			<h2>ART GALLERY</h2>
      
       

		</font>
		<nav>
		<ul>

			<li><a href = "#"> Home</a></li>
			<li><a href = "#"> Gallery</a></li>
			<li><a href = "contact.php"> Contact us</a></li>
      <div class="formbtn">
      <li><a href = "signupform.php"> Sign In </a></li>
      <li><a href = "loginform.php"> Log In</a></li>
      </div>
		</ul>
    </nav>

   





<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="slide1.jpg" height="350" width="700" />
  <div class="text">Caption Text</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="slide2.jpg"  height="350" width="700" />
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="slide3.jpg"  height="350" width="700" />
  <div class="text">Caption Three</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 2 seconds
}
</script>



    <h1>Recent products</h1> 


    <table align="center">
    	<tr>
    		<td>
    			<div class="arts">
    				<img src="1.jpg" height="300" width="400" />
    		</td>
    		<td>
    			<img src="2.jpg" height="300" width="400" />
    		</td>
    		<td>
    			<img src="3.jpg" height="300" width="400" />
    		</td>
    	</tr>

    	<tr>
    		<td>
    			<img src="4.jpg" height="300" width="400" />
    		</td>
    		<td>
    			<img src="5.jpg" height="300" width="400" />
    		</td>
    		<td>
    			<img src="6.jpg" height="300" width="400" />
    		</td>
    	</tr>
    </table>

    <footer>
      All Right Reserved Art Gallery
     </footer>

      
	</body>
	</html>
-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2021 at 05:27 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `artgallerymain`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_art`
--

CREATE TABLE `add_art` (
  `id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_art`
--

INSERT INTO `add_art` (`id`, `title`, `description`, `price`, `image_name`, `featured`, `active`) VALUES
(13, 'Mona Lisat', 'Leonardo da Vinci232', '695.00', 'Art-No-3134.webp', 'Yes', 'Yes'),
(14, 'Ipsum consequat Ut 432', 'Aut occaecat nih2323232il e', '234.00', 'Art-No-8745.jpg', 'Yes', 'Yes'),
(15, 'Sint sit est conse', 'Repudiandae vel volu', '433.00', 'Art-No-1739.jpg', 'Yes', 'Yes'),
(16, 'Sun & Moon', 'Ash Ketchup', '768.00', 'Art-No-2147.jpg', 'No', 'Yes'),
(17, 'Sit cum molestiae u', 'Velit fugiat ipsa ', '825.00', 'Art-No-329.jpg', 'No', 'Yes'),
(18, 'Architecto itaque re', 'Esse pariatur Molli', '574.00', 'Art-No-8028.jpg', 'No', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` int(11) NOT NULL,
  `firstName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `middleName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `lastName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `userName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `password` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `firstName`, `middleName`, `lastName`, `userName`, `email`, `password`) VALUES
(1, 'Al Juver ', 'Manos', 'Tingson', 'aljuver', 'aljuvertingson@gmail', 'tingson');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL,
  `firstName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `middleName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `lastName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `username` varchar(20) CHARACTER SET latin1 NOT NULL,
  `email` varchar(20) CHARACTER SET latin1 NOT NULL,
  `password` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerID`, `firstName`, `middleName`, `lastName`, `username`, `email`, `password`) VALUES
(12, 'Al Juver ', 'Manos', 'Tingson', 'aljuver', 'aljuvertingson@gmail', 'tingson'),
(14, 'AW', 'AW', 'AW', 'aw', 'aw', 'aw');

-- --------------------------------------------------------

--
-- Table structure for table `your_cart`
--

CREATE TABLE `your_cart` (
  `cartID` int(11) NOT NULL,
  `customerID` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `your_cart`
--

INSERT INTO `your_cart` (`cartID`, `customerID`, `title`, `price`) VALUES
(1, 0, 'Architecto itaque re', '574.00'),
(2, 0, 'Architecto itaque re', '574.00'),
(3, 0, 'Architecto itaque re', '574.00'),
(4, 14, 'Architecto itaque re', '574.00'),
(5, 14, 'Architecto itaque re', '574.00'),
(6, 14, 'Architecto itaque re', '574.00'),
(7, 12, 'Architecto itaque re', '574.00'),
(8, 12, 'Architecto itaque re', '574.00'),
(9, 12, 'Mona Lisat', '574.00'),
(10, 12, 'Ipsum consequat Ut 432', '574.00'),
(13, 12, 'Mona Lisat', '695.00'),
(15, 12, 'Architecto itaque re', '574.00'),
(16, 12, 'Mona Lisat', '695.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_art`
--
ALTER TABLE `add_art`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `your_cart`
--
ALTER TABLE `your_cart`
  ADD PRIMARY KEY (`cartID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_art`
--
ALTER TABLE `add_art`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `your_cart`
--
ALTER TABLE `your_cart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

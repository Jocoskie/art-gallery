<?php
session_start();
session_destroy();
unset($_SESSION['activeUser']);

echo "<script>window.open('Home.php', '_self')</script>";
?>

<?php
  include("../connect.php");

?>


<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <link rel="stylesheet" type="text/css" href="../formstyle.css">
</head>
<body>
  <div class="header">
    <h2>Register</h2>
    
   </div>

   <form action="#" method="POST"> 
    <div class="input-group">
      <label>First Name</label>
      <input type="text" name="firstname" placeholder="Enter firstname" required>
    </div>
    <div class="input-group">
      <label>Middle Name</label>
      <input type="text" name="middlename" placeholder="Enter middlename" required>
    </div>
    <div class="input-group">
      <label>Last Name</label>
      <input type="text" name="lastname" placeholder="Enter lastname" required>
    </div>
    <div class="input-group">
      <label>Username</label>
      <input type="text" name="username" placeholder="Enter username" required>
    </div>
    <div class="input-group">
      <label>Email</label>
      <input type="text" name="email" placeholder="Enter email" required>
    </div>
    <div class="input-group">
      <label>Password</label>
      <input type="password" name="password" placeholder="Enter password" required>
    </div>
    <div class="inputgroup">
      <button type="submit" name="register" class="btn">Register</button>
    </div>
     <div class="inputgroup">
      <button type="submit" value="Go back" onclick="history.back()" class="btn2">Cancel</button>
    </div>
    <p>
      Already a memeber? <a href="loginform.php">log in now!</a>
    </p>
   </form>

</body>
</html>

<?php
    if(isset($_POST['register'])){
      $FirstName = $_POST['firstname'];
      $MiddleName = $_POST['middlename'];
      $LastName = $_POST['lastname'];
      $Username = $_POST['username'];
      $Email = $_POST['email'];
      $Password = $_POST['password'];
      
      $sql = "INSERT into customer (firstName,middleName,lastName,username,email,password) VALUES ('$FirstName','$MiddleName','$FirstName','$Username','$Email','$Password')";
      $con->query($sql);

    }

?>


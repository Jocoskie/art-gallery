<?php
  include("../connect2.php");


  if(@$_SESSION['activeUser1'] == '')
    {
    echo "<script>alert('You must login first!');</script>";
    echo "<script>window.open('adminlogin.php', '_self');</script>";
    }
?>

<!DOCTYPE html>
<html>
    <head>
    <title> ART GALLERY ADMIN PAGE </title>
    <link rel="stylesheet" href="admin.css" type="text/css">
    </head>
 
<body>
  <div class="menu text-center wrapper main-content">
      <h1>Art Gallery Admin Page</h1>
      <center>
		  <ul>
        <li><a href = "adminhome.php"> Home</a></li>
        <li><a href = "add-art.php"> Add Art</a></li>
        <li><a href = "manage-order.php">Manage Art Orders</a></li>
        <li><a href = "logout.php"> Log Out</a></li>     
		  </ul>
      </center>
  </div>
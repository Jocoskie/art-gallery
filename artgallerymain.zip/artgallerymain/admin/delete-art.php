<?php 
    include("../connect2.php");

    if(isset($_GET['id']) && isset($_GET['image_name'])){
        $id = $_GET['id'];
        $image_name = $_GET['image_name'];

        if($image_name != ""){
            $path = "../images/art/".$image_name;

            $remove = unlink($path);

            if($remove==false){
                $_SESSION['upload-art'] = "<div class='error'>Failed to remove art image file.</div>";
                header('location:adminhome.php');
                die();
            }

        }

        $sql = "DELETE FROM add_art WHERE id=$id";
        $res = mysqli_query($con, $sql);

        if($res==true){
            $_SESSION['delete-art'] = "<div class='success'>Art deleted successfully.</div>";
            header('location:adminhome.php');
        }else{
            $_SESSION['delete-art'] = "<div class='error'>Failed to delete art data.</div>";
            header('location:adminhome.php');
        }
    }else{
        $_SESSION['unauthorize'] = "<div class='error'>Unauthorized access.</div>";
        header('location:adminhome.php');
    }

?>
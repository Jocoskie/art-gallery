<?php include('parts/header.php') ?>
<br>

<div class="main-content2">
    <h2>Manage Arts</h2>
    <center>
    <?php
        if(isset($_SESSION['add-art'])){
            echo $_SESSION['add-art'];
            unset($_SESSION['add-art']);
        }
        if(isset($_SESSION['upload-art'])){
            echo $_SESSION['upload-art'];
            unset($_SESSION['upload-art']);
        }
        if(isset($_SESSION['update-art'])){
            echo $_SESSION['update-art'];
            unset($_SESSION['update-art']);
        }
        if(isset($_SESSION['remove-failed'])){
            echo $_SESSION['remove-failed'];
            unset($_SESSION['remove-failed']);
        }
        if(isset($_SESSION['delete-art'])){
            echo $_SESSION['delete-art'];
            unset($_SESSION['delete-art']);
        }
        if(isset($_SESSION['unauthorize'])){
            echo $_SESSION['unauthorize'];
            unset($_SESSION['unauthorize']);
        }

    ?>
    </center>
    <table class="tbl-full">
                    <tr>
                        <th>S.N.</th>
                        <th>Art Name</th>
                        <th>Creator</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Featured</th>
                        <th>Active</th>
                        <th>Actions</th>
                    </tr>

                    <?php 
                        $sql = "SELECT * FROM add_art ORDER BY id DESC";

                        $res = mysqli_query($con, $sql);
                        $count = mysqli_num_rows($res);

                        $sn=1;

                        if($count>0)
                        {
                            while($row=mysqli_fetch_assoc($res))
                            {
                                $id = $row['id'];
                                $title = $row['title'];
                                $creator = $row['description'];
                                $price = $row['price'];
                                $image_name = $row['image_name'];
                                $featured = $row['featured'];
                                $active = $row['active'];
                                ?>

                                <tr>
                                    <td><?php echo $sn++; ?>. </td>
                                    <td><?php echo $title; ?></td>
                                    <td><?php echo $creator ?></td>
                                    <td>₱<?php echo $price; ?></td>
                                    <td>
                                        <?php  
                                            if($image_name=="")
                                            {
                                                echo "<div class='error'>Image not Added.</div>";
                                            }
                                            else
                                            {
                                                ?>
                                                <img src="../images/art/<?php echo $image_name; ?>" width="100px" style = "border: 1px solid white">
                                                <?php
                                            }
                                        ?>
                                    </td>
                                    <td><?php echo $featured; ?></td>
                                    <td><?php echo $active; ?></td>
                                    <td>
                                        <a href="edit-art.php?id=<?php echo $id; ?>" class="btn-secondary">Edit</a>
                                        <a href="delete-art.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name; ?>" class="btn-danger">Delete</a>
                                    </td>
                                </tr>

                                <?php
                            }
                        }
                        else
                        {
                            echo "<tr> <td colspan='7' class='error'> No art added yet. </td> </tr>";
                        }

                    ?>

                    
                </table>
  
</div>

<script type="text/javascript">
    function trylogout(){
        window.open("logout.php","_self");
    }
</script>
</body>
</html>
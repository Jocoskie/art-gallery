<?php include('parts/header.php') ?>
<br>

	<?php 
	    if(isset($_GET['id']))
	    {
	        $id = $_GET['id'];

	        $sql2 = "SELECT * FROM add_art WHERE id=$id";
	        $res2 = mysqli_query($con, $sql2);

	        $row2 = mysqli_fetch_assoc($res2);

	        $title = $row2['title'];
	        $creator = $row2['description'];
	        $price = $row2['price'];
	        $current_image = $row2['image_name'];
	        $featured = $row2['featured'];
	        $active = $row2['active'];

	    }
	    else
	    {
	        header('location: adminhome.php');
	    }
	?>

	<div class="main-content2">
		<div class="wrapper">
			<center>
				<h2>Edit Art Data</h2>

				<form action="" method="POST" enctype="multipart/form-data">
					<table class="tbl-30">
						<tr>
			                <td>Title: </td>
			                <td>
			                    <input type="text" name="title" value="<?php echo $title; ?>">
			                </td>
			            </tr>
			            <tr>
			                <td>Creator: </td>
			                <td>
			                    <textarea name="description" cols="20" rows="5"><?php echo $creator; ?></textarea>
			                </td>
			            </tr>
			            <tr>
			                <td>Price: </td>
			                <td>
			                    <input type="number" name="price" value="<?php echo $price; ?>">
			                </td>
			            </tr>
			            <tr>
			                <td>Current Art: </td>
			                <td>
			                    <?php 
			                        if($current_image == "")
			                        {
			                            //Image not Available 
			                            echo "<div class='error'>Image not Available.</div>";
			                        }
			                        else
			                        {
			                            //Image Available
			                            ?>
			                            <img src="../images/art/<?php echo $current_image; ?>" width="150px">
			                            <?php
			                        }
			                    ?>
			                </td>
			            </tr>
			            <tr>
			                <td>Select New Image: </td>
			                <td>
			                    <input type="file" name="image">
			                </td>
			            </tr>

			            <tr>
			                <td>Featured: </td>
			                <td>
			                    <input <?php if($featured=="Yes") {echo "checked";} ?> type="radio" name="featured" value="Yes"> Yes 
			                    <input <?php if($featured=="No") {echo "checked";} ?> type="radio" name="featured" value="No"> No 
			                </td>
			            </tr>

			            <tr>
			                <td>Active: </td>
			                <td>
			                    <input <?php if($active=="Yes") {echo "checked";} ?> type="radio" name="active" value="Yes"> Yes 
			                    <input <?php if($active=="No") {echo "checked";} ?> type="radio" name="active" value="No"> No 
			                </td>
			            </tr>

			            <tr>
			                <td colspan="2">
			                    <input type="hidden" name="id" value="<?php echo $id; ?>">
			                    <input type="hidden" name="current_image" value="<?php echo $current_image; ?>">

			                    <input type="submit" name="submit" value="Update Art" class="btn-secondary">
			                </td>
			            </tr>

					</table>
				</form>

				<?php 
        
		            if(isset($_POST['submit'])){

		                $id = $_POST['id'];
		                $title = $_POST['title'];
		                $description = $_POST['description'];
		                $price = $_POST['price'];
		                $current_image = $_POST['current_image'];
		                $featured = $_POST['featured'];
		                $active = $_POST['active'];

		                if(isset($_FILES['image']['name'])){
		                    $image_name = $_FILES['image']['name'];
		                    if($image_name!=""){
		                        $ext = end(explode('.', $image_name));
		                        $image_name = "Art-No-".rand(0000, 9999).'.'.$ext;

		                        $src_path = $_FILES['image']['tmp_name'];
		                        $dest_path = "../images/art/".$image_name;
		                        $upload = move_uploaded_file($src_path, $dest_path);

		                        if($upload==false){
		                            $_SESSION['upload-art'] = "<div class='error'>Failed to upload new image.</div>";
		                            header('location:adminhome.php');
		                            die();
		                        }

		                        if($current_image!=""){
		                            $remove_path = "../images/art/".$current_image;

		                            $remove = unlink($remove_path);

		                            if($remove==false){
		                                $_SESSION['remove-failed'] = "<div class='error'>Failed to remove current image.</div>";
		                                header('location:adminhome.php');
		                                die();
		                            }
		                        }
		                    }
		                    else
		                    {
		                        $image_name = $current_image;
		                    }
		                }
		                else
		                {
		                    $image_name = $current_image;
		                }

		                $sql = "UPDATE add_art SET 
		                    title = '$title',
		                    description = '$description',
		                    price = $price,
		                    image_name = '$image_name',
		                    featured = '$featured',
		                    active = '$active'
		                    WHERE id=$id
		                ";

		                $res = mysqli_query($con, $sql);

		                if($res==true)
		                {
		                    $_SESSION['update-art'] = "<div class='success'>Art updated successfully.</div>";
		                    header('location:adminhome.php');
		                }
		                else
		                {
		                    $_SESSION['update-art'] = "<div class='error'>Failed to update art.</div>";
		                    header('location:adminhome.php');
		                }

		                
		            }
		        
		        ?>

				<br><br>
			</center>
		</div>

	</div>



<script type="text/javascript">
    function trylogout(){
        window.open("logout.php","_self");
      }
  </script>
</body>
</html>
<?php
  include("../connect2.php");

  if(@$_SESSION['activeUser1'] != ""){
    echo "<script>alert('User has already logged in');</script>";
    echo "<script>window.open('adminhome.php', '_self');</script>";
  }
?>

<!DOCTYPE html>
  <html>
  <head>
    <title>Login Admin</title>
    <link rel="stylesheet" type="text/css" href="adminloginformstyle.css">
  </head>
  <body>
  <div class="header">
    <h2>Login Admin</h2>
   </div>

   <form method="POST" action="#">
    <div class="input-group">
      <label>Username: </label>
      <input type="text" name="username" placeholder="Enter Username" required>
    </div>
    <div class="input-group">
      <label>Password: </label>
      <input type="password" name="password" placeholder="Enter Password" required>
    </div>
    <div class="inputgroup">
      <button type="submit" name="login" class="btn">Login</button>
    </div>
    <br>
    <div class="inputgroup">
      <a href="../home.php" class="cancelbtn">Cancel</a>
    </div>
    <form>

    <br>
    <p>
      Register as? <a href="signupform.php">Admin</a>
    </p>

   </form>

</body>
</html>

<?php
  if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

  $sql = "SELECT * from customer where userName = '$username' and password = '$password'";
  $query = $con->query($sql);

  if($query->num_rows>0){
    echo "<script type>alert('Login Success!');</script>";
    while ($row = $query->fetch_assoc()){
      $_SESSION['activeUser1'] = $row['username'];
      echo "<script>window.open('adminhome.php','_self')</script>";
    }
  }else{
    echo "<script>alert('Invalid Username/Password!');</script>";
  }
  }


  
?>
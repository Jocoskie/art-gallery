<?php include("parts/header.php")?>

    <div class="slideshow-container">

    <div class="mySlides fade">
      <div class="numbertext">1 / 3</div>
      <img src="slide1.jpg" height="350" width="700" />
      <div class="text">Caption Text</div>
    </div>

    <div class="mySlides fade">
      <div class="numbertext">2 / 3</div>
      <img src="slide2.jpg"  height="350" width="700" />
      <div class="text">Caption Two</div>
    </div>

    <div class="mySlides fade">
      <div class="numbertext">3 / 3</div>
      <img src="slide3.jpg"  height="350" width="700" />
      <div class="text">Caption Three</div>
    </div>

    </div>
    <br>

    <div style="text-align:center">
      <span class="dot"></span> 
      <span class="dot"></span> 
      <span class="dot"></span> 
    </div>

<script>
  var slideIndex = 0;
  showSlides();

  function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 5000);
    }
</script>

    <center>
    <h1>RECENT PRODUCTS ADDED</h1> 
    </center>

    <div class="container">
        <center>
            <?php 

            $sql = "SELECT * FROM add_art where featured='Yes' and active = 'Yes'";

            $res = mysqli_query($con, $sql);

            $count = mysqli_num_rows($res);

            if($count>0){
                while($row=mysqli_fetch_assoc($res)){
                    $id = $row['id'];
                    $title = $row['title'];
                    $price = $row['price'];
                    $description = $row['description'];
                    $image_name = $row['image_name'];
                    ?>

                    <div class="art-box">
                        <div class="art-img">
                            <?php 
                                if($image_name=="")
                                {
                                    echo "<div class='error'>Image not available.</div>";
                                }
                                else
                                {
                                    ?>
                                    <img src="images/art/<?php echo $image_name; ?>" alt="Art image" class="img-class">
                                    <?php
                                }
                            ?>
                            
                        </div>

                        <div class="art-desc">
                            <h4><?php echo $title; ?></h4>
                            <p class="art-price">₱<?php echo $price; ?></p>
                            <p class="art-detail">
                                <?php echo $description; ?>
                            </p>
                            <br>
                        </div>
                    </div>

                    <?php
                }
            }
            else
            {
                echo "<div class='error'>Art not added yet.</div>";
            }
            
            ?>
            <a href="usergallery.php">See all Art Products</a>
          </center>
  </div>


<?php include("parts/footer.php")?>
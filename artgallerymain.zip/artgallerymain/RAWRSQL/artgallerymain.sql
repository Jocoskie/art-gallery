-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2021 at 12:47 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `artgallerymain`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` int(11) NOT NULL,
  `firstName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `middleName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `lastName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `userName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `password` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `firstName`, `middleName`, `lastName`, `userName`, `email`, `password`) VALUES
(1, 'Al Juver ', 'Manos', 'Tingson', 'aljuver', 'aljuvertingson@gmail', 'tingson');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL,
  `firstName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `middleName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `lastName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `username` varchar(20) CHARACTER SET latin1 NOT NULL,
  `email` varchar(20) CHARACTER SET latin1 NOT NULL,
  `password` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerID`, `firstName`, `middleName`, `lastName`, `username`, `email`, `password`) VALUES
(12, 'Al Juver ', 'Manos', 'Tingson', 'aljuver', 'aljuvertingson@gmail', 'tingson'),
(14, 'AW', 'AW', 'AW', 'aw', 'aw', 'aw');

-- --------------------------------------------------------

--
-- Table structure for table `tbl-art`
--

CREATE TABLE `tbl-art` (
  `id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_art`
--

CREATE TABLE `tbl_art` (
  `id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_art`
--

INSERT INTO `tbl_art` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(1, 'w', 'w', '1.00', 'Food-Name-2936.jpg', 0, 'Yes', 'Yes'),
(2, '1', '23', '1.00', 'Food-Name-4902.jpg', 0, 'Yes', 'Yes'),
(3, 's', 'q', '1.00', 'Food-Name-166.jpg', 0, 'Yes', 'Yes'),
(4, '1', '2', '1.00', 'Food-Name-494.jpg', 0, 'Yes', 'Yes'),
(5, 'qq', 'q', '1.00', 'Food-Name-1163.jpg', 0, 'Yes', 'Yes'),
(6, 'q', 'qw', '1.00', 'Food-Name-3567.jpg', 0, 'Yes', 'Yes'),
(7, 'q', 'w', '5.00', 'Food-Name-4193.jpg', 0, 'No', 'No'),
(8, 's', 's', '2.00', 'Food-Name-2661.jpg', 0, 'No', 'No');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `tbl-art`
--
ALTER TABLE `tbl-art`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_art`
--
ALTER TABLE `tbl_art`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl-art`
--
ALTER TABLE `tbl-art`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_art`
--
ALTER TABLE `tbl_art`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

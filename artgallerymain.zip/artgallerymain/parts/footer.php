    <br><br>
    <div class="footer container2">
      All Right Reserved - Art Gallery
     </div>

<script type="text/javascript">
    function trylogout(){
        window.open("logout.php","_self");
      }
  </script>
      
	</body>
	</html>
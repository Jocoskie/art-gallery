<?php
  include("connect2.php");

  $name = @$_SESSION['activeUser'];
  $globaluser = @$_SESSION['activeUserID'];
  if(@$_SESSION['activeUser'] == '')
    {
    echo "<script>alert('You must login first!');</script>";
    echo "<script>window.open('loginform.php', '_self');</script>";
    }
?>

<!DOCTYPE html>
<html>
<head>
  <title> WELCOME TO ART GALLERY! </title>
	<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
  <center>
	<h2>WELCOME TO ART GALLERY!</h2>
		<nav>
		  <ul>

		    <li><a href = "userhome.php"> Home</a></li>
        <li><a href = "usergallery.php"> Gallery</a></li>
        <li><a href = "usercontact.php"> Contact us</a></li>

        <div class="formbtn">
        <li><a href=""><?php echo $name; ?></a></li>
        <li><a href = "usercart.php">Your Cart</a></li>
        <li><a href = "logout.php"> Log out</a></li>
        </div>

		  </ul>
    </nav>

   </center> 
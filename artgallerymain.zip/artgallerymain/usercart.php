<?php include("parts/header.php")?>
<br>

<div class="container">
	<center>
		<h1>YOUR CART</h1>
		<table>
			<tr>
				<th>ID</th>
				<th>Title</th>
				<th>Price</th>
			</tr>
			<?php
				$sql = "SELECT * FROM your_cart WHERE customerID = $globaluser";
				$res = mysqli_query($con, $sql);
				$count = mysqli_num_rows($res);
				$total = 0.;
				if($count > 0){
					while($row = mysqli_fetch_assoc($res)){
						$id = $row['cartID'];
						$title = $row['title'];
						$price = $row['price'];
						$total += $price;
						?>
						<tr>
							<td><center><?php echo $id; ?></center></td>
							<td><?php echo $title; ?></td>
							<td><?php echo $price; ?></td>
						</tr>
						<?php
					}
					?>
					<tr>
						<td>----------</td>
						<td>----------------------------------</td>
						<td>----------</td>
					</tr>
					<tr>
						<td>Total</td>
						<td></td>
						<td><center><?php echo $total; ?>.00</center></td>
					</tr>

					<?php
				}
			?>
			
		</table>
	</center>
</div>

<?php include("parts/footer.php")?>
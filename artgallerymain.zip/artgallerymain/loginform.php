<?php
  include("connect2.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="formstyle.css">
</head>
<body>
  <div class="header">
    <h2>Login</h2>
   </div>

   <form method="POST" action="#">
    <div class="input-group">
      <label>Username: </label>
      <input type="text" name="username" placeholder="Enter Username" required>
    </div>
    <div class="input-group">
      <label>Password: </label>
      <input type="password" name="password" placeholder="Enter Password" required>
    </div>
    <div class="inputgroup">
      <button type="submit" name="login" class="btn">Login</button>
    </div>
    <div class="inputgroup">
      <button type="submit" value="Go back" onclick="history.back()" class="btn2">Cancel</button>
    </div>
    <form>



    <br>
    <p>
      Not yet a member? <a href="signupform.php">Sign in now!</a>
    </p>
     <p>
      Log In as <a href="adminlogin.php">admin!</a>
    </p>

   </form>

</body>
</html>

<?php
  if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

  $sql = "SELECT * from customer where userName = '$username' and password = '$password'";
  $query = $con->query($sql);

  if($query->num_rows>0){
    echo "<script type>alert('Login Success!');</script>";
    while ($row = $query->fetch_assoc()){
    //echo "First Name: ".$row['FirstName']." Middle Name: ".$row['MiddleName']." LastName:".$row['LastName']."<br />";
    //session_start();

    $_SESSION['activeUser'] = $row['username'];
    $_SESSION['activeUserID'] = $row['customerID'];
    //echo $_SESSION['activeUser'];
    echo "<script>window.open('userhome.php','_self')</script>";
    

    }
  }else{
    echo "<script>alert('Invalid Username/Password!');</script>";
  }
  }


  
?>
<?php include("parts/header.php")?>

<br>
<center>
  <h1>THE ART GALLERY</h1>
  <br>
  <h2>Check two box to add into your cart.</h2>
  <br><br>
</center>
<form method="POST" action="">
<div class="gallery">
<table align="center">

  <?php 
    $sql = "SELECT * FROM add_art where active = 'Yes'";

    $res = mysqli_query($con, $sql);
    $count = mysqli_num_rows($res);

    if($count>0){
        while($row=mysqli_fetch_assoc($res)){
          $id = $row['id'];
          $title = $row['title'];
          $creator = $row['description'];
          $price = $row['price'];
          $image_name = $row['image_name'];
          $featured = $row['featured'];
          $active = $row['active'];
          ?>
            <tr>
            <td>
              <div class="card">
                <?php
                  if($image_name==""){
                    echo "<div class='error'>Image not Added.</div>";
                  }else{
                    ?>  
                    <img src="images/art/<?php echo $image_name; ?>" alt="" height="300" width="300" style = "border: 1px solid white" class= "img-class">
                    <?php
                  }
                ?>
                <p class="title">"<?php echo $title; ?>"</p>
                <p class="title">By <?php echo $creator; ?></p>
                <p class="price">₱<?php echo $price; ?></p>
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <input type="checkbox" name="title_art" value="<?php echo $title; ?>">
                <input type="checkbox" name="price_art" value="<?php echo $price; ?>">
                <p><input type="submit" name="AddToCart" value="Add to Cart"></p>
              </div>
            </td>
            </tr>

          <?php
        }
      }else{
        echo "<tr> <td colspan='7' class='error'> No art added yet. </td> </tr>";
      }
  ?>
</table>
</div>
</form>

<?php
  if(isset($_POST['AddToCart'])) {
        $titleArt = $_POST['title_art'];
        $priceArt = $_POST['price_art'];

        $sql2 = "INSERT INTO your_cart SET
          customerID = '$globaluser',
          title = '$titleArt',
          price = '$priceArt'
        ";

        $query2 = $con->query($sql2);

          if($query2==true)
          {
            echo "<script type>alert('Art added to cart!');</script>";
          }
          else
          {
            echo "<script type>alert('Failed.');</script>";
            die();
          }
  }

?>
    
   
<?php include("parts/footer.php")?>

<?php 
    //Start Session
    session_start();

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "artgallerymain";

    $con = new mysqli($servername, $username, $password, $dbname);

?>